#!/usr/bin/perl
#
#	avg.pl <file>
#	Compute the averages
#---------------------------------------------------------------------


open(IN, "$ARGV[0]");
$nin = 0;
#Title line
$in_rec = <IN>;
print "$in_rec";
while ($in_rec = <IN>)
{
	$nin++;
#GENE*.txt
        ($in_name, $in_chr, $in_start, $in_end, @in_vals) = split(/\t|\r|\n/, $in_rec);
	$len = $in_end - $in_start;
	print "$in_chr\t$in_start\t$in_end\t$in_name";
#print STDERR "$name start=$in_start end=$in_end len=$len\n";
	if ($len > 0)
	{
		foreach $val (@in_vals)
		{
        		if (isnumeric($val))
			{
				$x = ($val / $len);
				$mean = round($x);
				print "\t$mean";
#print STDERR "$name val=$val len=$len avg=$mean\n";
			}
			else
			{ print STDERR "ERROR $val not numeric for $in_name\n"; }
		}
	}
	else
	{  print STDERR "ERROR $len less than zero for $in_name\n"; }
	print "\n";
} # end of in_rec
close(IN);
exit(0);
#=========================================================================
#   Round a number to three decimal places
sub round
{
  local($x) = @_;
  local($xround);

  $xround = 1000 * $x;
  if ($x >= 0.0)
  {  $xround = int($xround + 0.5);  }
  else
  {  $xround = int($xround - 0.5);  }
  $xround /= 1000;

  return($xround);
} # end of round
#======================================================================
sub isnumeric 
{
    local($x) = @_;
    local($numflag);

    if ($x !~/^[0-9|.|,|-]*$/) 
    { $numflag = 0; }
    else 
    { $numflag = 1; }

    #Check for 9.9e-99, etc.
    if ($numflag==0 && $x =~ m/(\d+)e-(\d+)/)
    { $numflag = 1; }

    return($numflag);
}  #end of isnumeric
