#!/usr/bin/perl
#
#	diff_cols.pl <file> <col1> <col2>
#	Computes col1-col2 and appends it to input record
#
if ($#ARGV < 0)
{
   print STDERR "USAGE: diff_cols.pl <data file> [<col1> <col2>]\n";
   exit(-1);
}
$col1 = 2; $col2 = 3;
if ($#ARGV > 1)
{   $col1 = $ARGV[1], $col2 = $ARGV[2]; }
if ($col1 < 2) { $col1 = 2; }
if ($col2 < 2) { $col2 = 3; }
print STDERR "Computing col${col1} - col${col2} of $ARGV[0]\n";
#Adjust col numbers for id and values list offset
$col1 -= 2; $col2 -= 2;

if (-e $ARGV[0]) { open(IN, "<$ARGV[0]");}
else
{
   print STDERR "$ARGV[0] does not exist\n";
   exit(-1);
}
while ($in_rec = <IN>)
{
   ($id, @values) = split(/\t|\r|\n/, $in_rec);
   if (isnumeric($values[$col1]) && isnumeric($values[$col2]))
   {
      $x = $values[$col1] - $values[$col2];
      $diff = &round($x);
      $absdiff = $diff;
      if ($absdiff < 0) { $absdiff = 0 - $diff; }
   }
   else
   { $diff = $absdiff = "na"; }
#  print "$id\t$val1\t$val2\t$diff\t$absdiff\n";
#  print "$id\t$values[$col1]\t$values[$col2]\t$diff\n";
#  print "$id\t$diff\n";
   chomp($in_rec);
   print "$in_rec\t$diff\n";
}
close(IN); 
exit(0);
#=========================================================================
#   Round a number to six decimal places
sub round
{
  local($x) = @_;
  local($xround);

  $xround = 1000000 * $x;
  if ($x >= 0.0)
  {  $xround = int($xround + 0.5);  }
  else
  {  $xround = int($xround - 0.5);  }
  $xround /= 1000000;

  return($xround);
} # end of round
#======================================================================
sub isnumeric 
{
    local($x) = @_;
    local($numflag);

    if ($x !~/^[0-9|.|,|-]*$/) 
    { $numflag = 0; }
    else 
    { $numflag = 1; }

    #Check for 9.9E-99, etc.
    if ($numflag==0 && $x =~ m/(\d+)[Ee][+-](\d+)/)
    { $numflag = 1; }

    #Check for nulls
    if ($x eq "") { $numflag = 0; }

    return($numflag);
}  #end of isnumeric
