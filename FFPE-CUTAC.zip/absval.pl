#!/usr/bin/perl
#
#	absval.pl <file>
#	Adds max(absval) of cols 5- along with column type
#	Expects rigid input format
#CCRE	chr	start	end	P1T-N	P2T-N	RT-N	YT-N
#---------------------------------------------------------------------


open(IN, "$ARGV[0]");
$nin = $nout = 0;
#Title line
$in_rec = <IN>;
print "$in_rec";
while ($in_rec = <IN>)
{
	$nin++;
        ($in_name, $in_chr, $in_start, $in_end, $in_P1, $in_P2, $in_R, $in_Y) = split(/\t|\r|\n/, $in_rec);
        if ($in_P1 < 0) { $P1 = 0.0 - $in_P1; }
        else { $P1 = $in_P1; }
        if ($in_P2 < 0) { $P2 = 0.0 - $in_P2; }
        else { $P2 = $in_P2; }
        if ($in_R < 0) { $R= 0.0 - $in_R; }
        else { $R = $in_R; }
        if ($in_Y < 0) { $Y = 0.0 - $in_Y; }
        else { $Y = $in_Y; }
	$max = $P1; $val = $in_P1; $type = "P1";
	if ($P2 > $max) { $max = $P2; $val = $in_P2; $type = "P2"; }
	if ($R > $max) { $max = $R; $val = $in_R; $type = "R"; }
	if ($Y	> $max) { $max = $Y; $val = $in_Y; $type = "Y"; }
	chop($in_rec);
	print "$in_rec\t$val\t$type\n";
	$nout++;
} # end of in_rec
print STDERR "nin=$nin nout=$nout\n";
close(IN);
exit(0);
#=========================================================================
#   Return absolute value
sub absval
{
  local($x) = @_;
  local($xabs);

  if ($x < 0) { $xabs = 0.0 - $x;}
  else        { $xabs = $x; }
  return($xabs);
} #end of absval
#=========================================================================
